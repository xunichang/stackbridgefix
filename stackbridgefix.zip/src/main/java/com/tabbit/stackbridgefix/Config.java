package com.tabbit.stackbridgefix;

import net.minecraftforge.common.ForgeConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

/**
 * COMMON config for the recursion guard.
 */
public final class Config {

    public static final ForgeConfigSpec SPEC;
    public static final Common COMMON;

    static {
        Pair<Common, ForgeConfigSpec> pair = new ForgeConfigSpec.Builder().configure(Common::new);
        COMMON = pair.getLeft();
        SPEC = pair.getRight();
    }

    private Config() {
    }

    public static class Common {

        public final ForgeConfigSpec.BooleanValue enabled;
        public final ForgeConfigSpec.IntValue maxDepth;

        Common(ForgeConfigSpec.Builder builder) {
            builder.comment("诸神栈桥堆积修复 / Stack Bridge Fix").push("general");

            enabled = builder
                    .comment("是否启用递归保护。/ Whether the recursion guard is active.")
                    .define("enabled", true);

            maxDepth = builder
                    .comment("onLivingHurt 允许的最大嵌套深度，超过即切断失控的伤害链。",
                            "正常战斗的嵌套深度通常只有个位数，所以 20 非常安全。",
                            "Maximum nested onLivingHurt depth before the runaway chain is cut.",
                            "Normal combat nests only a few levels deep, so 20 is very safe.")
                    .defineInRange("maxDepth", 20, 4, 512);

            builder.pop();
        }
    }
}
