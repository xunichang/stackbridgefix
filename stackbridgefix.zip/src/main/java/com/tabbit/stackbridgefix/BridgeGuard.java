package com.tabbit.stackbridgefix;

/**
 * Per-thread re-entrancy depth counter for the damage pipeline.
 *
 * <p>We use a raw {@code int[]} held in a {@link ThreadLocal} to avoid boxing on the
 * hot path. The counter is bumped on entry to {@code ForgeHooks.onLivingHurt} and
 * lowered on exit. When the depth exceeds the configured maximum we know the same
 * thread has recursively re-entered the hurt pipeline (a runaway feedback loop) and
 * the mixin cuts it.</p>
 */
public final class BridgeGuard {

    private static final ThreadLocal<int[]> DEPTH = ThreadLocal.withInitial(() -> new int[]{0});

    private static volatile int maxDepth = 20;
    private static volatile boolean enabled = true;

    private BridgeGuard() {
    }

    /** Increments and returns the new depth for the current thread. */
    public static int enter() {
        int[] depth = DEPTH.get();
        return ++depth[0];
    }

    /** Decrements the depth for the current thread (never below zero). */
    public static void exit() {
        int[] depth = DEPTH.get();
        if (depth[0] > 0) {
            depth[0]--;
        }
    }

    public static int getMaxDepth() {
        return maxDepth;
    }

    public static void setMaxDepth(int value) {
        maxDepth = value;
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setEnabled(boolean value) {
        enabled = value;
    }
}
