package com.tabbit.stackbridgefix.mixin;

import com.tabbit.stackbridgefix.BridgeGuard;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.common.ForgeHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Injects a per-thread depth guard into {@code ForgeHooks.onLivingHurt}.
 *
 * <p>Signature (1.20.1): {@code public static float onLivingHurt(LivingEntity entity,
 * DamageSource src, float amount)}.</p>
 *
 * <p>Every level of the runaway loop passes through this method, so counting nesting
 * here is enough to detect and stop it. We return {@code 0.0F} (the same value vanilla
 * uses when the {@code LivingHurtEvent} is cancelled) to void the over-deep nested
 * damage, which breaks the chain without throwing any exception. The first, legitimate
 * hit is unaffected because it never exceeds the configured depth.</p>
 *
 * <p>{@code remap = false} on both the class and the method: {@code ForgeHooks} and its
 * method names are not obfuscated in either the dev or the production (SRG) environment,
 * so no refmap lookup is required.</p>
 */
@Mixin(value = ForgeHooks.class, remap = false)
public class ForgeHooksMixin {

    @Inject(method = "onLivingHurt", at = @At("HEAD"), cancellable = true, remap = false)
    private static void stackbridgefix$guardEnter(LivingEntity entity, DamageSource source, float amount,
                                                  CallbackInfoReturnable<Float> cir) {
        if (!BridgeGuard.isEnabled()) {
            return;
        }

        int depth = BridgeGuard.enter();
        if (depth > BridgeGuard.getMaxDepth()) {
            // Runaway re-entrancy detected. Balance the counter (RETURN handlers do not run
            // on a cancelled HEAD) and void the over-deep nested damage.
            BridgeGuard.exit();
            cir.setReturnValue(0.0F);
        }
    }

    @Inject(method = "onLivingHurt", at = @At("RETURN"), remap = false)
    private static void stackbridgefix$guardExit(LivingEntity entity, DamageSource source, float amount,
                                                 CallbackInfoReturnable<Float> cir) {
        if (!BridgeGuard.isEnabled()) {
            return;
        }
        BridgeGuard.exit();
    }
}
