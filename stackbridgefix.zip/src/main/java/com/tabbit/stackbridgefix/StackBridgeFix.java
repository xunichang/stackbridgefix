package com.tabbit.stackbridgefix;

import com.mojang.logging.LogUtils;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * 诸神栈桥堆积修复 / Stack Bridge Fix
 *
 * <p>Cuts the runaway recursive damage chain that ends in a {@link StackOverflowError}
 * when several mods re-enter {@code ForgeHooks.onLivingHurt} on the same thread
 * (for example goety_ladder's relic handler and apotheosis_modern_ragnarok's
 * BloodBulletBonus dealing damage again inside the {@code LivingHurtEvent}).</p>
 *
 * <p>The actual guard lives in {@code ForgeHooksMixin}; this class only registers the
 * config and keeps {@link BridgeGuard} in sync with it.</p>
 */
@Mod(StackBridgeFix.MODID)
public class StackBridgeFix {

    public static final String MODID = "stackbridgefix";

    private static final Logger LOGGER = LogUtils.getLogger();

    public StackBridgeFix() {
        // Config
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);

        // Keep the fast-path guard values in sync with the config.
        FMLJavaModLoadingContext.get().getModEventBus().addListener(this::onConfigEvent);

        // Harmless self-registration so the mod bus lives; the guard itself is a Mixin.
        MinecraftForge.EVENT_BUS.register(this);

        LOGGER.info("[StackBridgeFix] Loaded. Recursion guard enabled={}, maxDepth={}",
                BridgeGuard.isEnabled(), BridgeGuard.getMaxDepth());
    }

    private void onConfigEvent(ModConfigEvent event) {
        if (MODID.equals(event.getConfig().getModId())) {
            BridgeGuard.setEnabled(Config.COMMON.enabled.get());
            BridgeGuard.setMaxDepth(Config.COMMON.maxDepth.get());
            LOGGER.info("[StackBridgeFix] Config applied. enabled={}, maxDepth={}",
                    BridgeGuard.isEnabled(), BridgeGuard.getMaxDepth());
        }
    }

    @SubscribeEvent
    public void onServerStarting(net.minecraftforge.event.server.ServerStartingEvent event) {
        // no-op; kept to guarantee the common bus registration is valid.
    }
}
