# 诸神栈桥堆积修复 / Stack Bridge Fix

修复《落幕曲》整合包中"伤害叠太高 → 打实体/打假人 → 游戏崩溃（StackOverflowError）"的问题。

## 原理

崩溃是一条**同线程无限递归**的伤害链：

```
LivingEntity.actuallyHurt
  → ForgeHooks.onLivingHurt            (第 1 层)
      → LivingHurtEvent
          → goety_ladder 遗物处理器 / apotheosis_modern_ragnarok 血弹奖励
              → 再次造成伤害
                  → LivingEntity.actuallyHurt
                      → ForgeHooks.onLivingHurt   (第 2 层)
                          → …… 直到栈溢出
```

本模组用 Mixin 在 `ForgeHooks.onLivingHurt` 里放了一个**每线程深度计数器**：

- 正常战斗：嵌套深度只有个位数，**完全不受影响**。
- 失控链：一旦嵌套深度超过阈值（默认 20），直接返回 `0.0F`（等同于原版取消该次伤害的事件），把失控的"幽灵伤害"掐断。

掐断时**不会报错**：返回 0 只是让那一层多余的嵌套伤害不生效，最外层你真正打出的那次伤害照常结算。

## 构建

需要 JDK 17+（21 也可）与 Gradle（或用 wrapper）。

```bash
# 1) 生成 wrapper（只需一次，若本地没有 gradle 可跳过此步）
gradle wrapper

# 2) 构建
# Windows CMD:
gradlew.bat build
# Linux / macOS / PowerShell:
./gradlew build
```

产物：`build/libs/stackbridgefix-1.0.0.jar`

## 安装

把 `stackbridgefix-1.0.0.jar` 放进整合包的 `mods/` 文件夹即可。仅服务端逻辑，客户端/服务端均可（单人游戏直接放 mods）。

## 配置

首次运行后生成 `config/stackbridgefix-common.toml`：

```toml
[general]
    # 是否启用递归保护
    enabled = true
    # onLivingHurt 允许的最大嵌套深度，超过即切断
    maxDepth = 20
```

- `maxDepth` 越小，掐断越早、幽灵伤害越少；越大越保守。
- 正常战斗嵌套深度极浅，20 已经非常安全。若仍有崩溃可降到 10 或 8。
